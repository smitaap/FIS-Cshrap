﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        CompareValidator1.ValueToCompare = DateTime.Now.ToShortDateString()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (Page.IsValid) Then
            lblOutput.Text = "Details Saved Successfully"
        End If
    End Sub

    Protected Sub tbDate_TextChanged(sender As Object, e As EventArgs) Handles tbDate.TextChanged

    End Sub


End Class