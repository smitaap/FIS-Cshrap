namespace WebApplication4.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using WebApplication4.Models;
    internal sealed class Configuration : DbMigrationsConfiguration<WebApplication4.Models.CustomerModel>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(WebApplication4.Models.CustomerModel context)
        {
            var d1 = new Customer() { CustomerName="Smita" };
            var d2 = new Customer() { CustomerName="Nayan" };
            context.Customers.AddOrUpdate(d => d.CustomerName, d1, d2);

        }
    }
}
