﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication4.Models;

namespace WebApplication4
{
    public partial class CustomerUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //if (!IsPostBack)
            //{
            //    LoadGridView();
            //}

        }
        private void LoadGridView()
        {
            using (var context = new CustomerModel())
            {
                try
                {
                    var Query = from item in context.Customers
                                select item;
                    gvCustomers.DataSource = Query.ToList();
                    gvCustomers.DataBind();
                }
                catch (Exception ex)
                {
                    lblmsg.Text = ex.Message;
                }
            }
        }
       
        
        protected void btDelete_Click(object sender, EventArgs e)
        {
            using (var context = new CustomerModel())
            {
                try
                {
                    int id = Convert.ToInt32(txtId.Text);

                    var obj = context.Customers.Find(id);
                    //var obj = (from item in context.Departments
                    //          where item.DepartmentName == txtName.Text
                    //          select item).FirstOrDefault();

                    context.Customers.Remove(obj);

                    int Rows = context.SaveChanges();
                    if (Rows == 1)
                    {
                        lblmsg.Text = "Customer deleted";
                        LoadGridView();
                    }

                }
                catch (Exception ex)
                {

                    lblmsg.Text = ex.Message;
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (var context = new CustomerModel())
            {
                try
                {
                    var obj = new Customer();
                    obj.CustomerName = txtName.Text;
                    
                    obj.CustomerEmail = txtMail.Text;
                    
                    obj.CustomerPhone =Convert.ToInt32( txtPhone.Text);

                    context.Customers.Add(obj);
                    

                    int Rows = context.SaveChanges();
                    if (Rows == 1)
                    {
                        lblmsg.Text = "Customer added";
                        LoadGridView();
                    }

                }
                catch (Exception ex)
                {
                    lblmsg.Text = ex.Message;
                }
            }
        }

        protected void btDisplay_Click(object sender, EventArgs e)
        {
            LoadGridView();
        }
    }
}