﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Request.QueryString["username"]!=null)
            {
                var value = Request.QueryString["username"];
                lblUser.Text = value;

            }
        }

        protected void LoginStatus1_LoggingOut(object sender, LoginCancelEventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btlogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
            Session.Remove("Key1");
            Session.Clear();
            Session.Abandon();
        }
    }
}