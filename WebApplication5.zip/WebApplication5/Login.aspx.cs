﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var name = txtName.Text;
            Response.Redirect("~/Home.aspx?username=" + name);
            var cookie = new HttpCookie("UserNameCookie");
            cookie["user"] = txtName.Text;
            //Response.Cookies.Add(cookie);

            //if (CheckBox1.Checked)
            //{
            //    cookie.Expires = DateTime.Now.AddMinutes(10);
            //}
            //Response.Cookies.Add(cookie);
            Session["Key1"] = txtName.Text;

        }
        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        
    }
}